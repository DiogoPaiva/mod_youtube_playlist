<?php

namespace ModYoutubePlaylist\Helper;

use Joomla\CMS\Log\Log;
use Joomla\CMS\Http\HttpFactory;

class YoutubePlaylistHelper
{
    public static function fetchVideos(string $playlistId, int $maxResults = 5): array
    {
        $ajaxUrl = \JUri::root() . 'index.php?option=com_ajax&plugin=youtube_playlist&format=json&playlist_id=' . $playlistId . '&max_results=' . $maxResults;

        try {
            $http = HttpFactory::getHttp();
            $response = $http->get($ajaxUrl);
            $data = json_decode($response->body, true);

            if (!empty($data['data']['videos'])) {
                return $data['data']['videos'];
            }
        } catch (\Exception $e) {
            Log::add('[mod_youtube_playlist] Erro ao obter vídeos: ' . $e->getMessage(), Log::ERROR, 'mod_youtube_playlist');
        }

        return [];
    }
}
