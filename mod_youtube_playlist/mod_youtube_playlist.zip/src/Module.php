<?php

namespace ModYoutubePlaylist;

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;

class Module
{
    public function getMessage()
    {
        Factory::getApplication()->getLogger()->info('[mod_youtube_playlist] Module::getMessage chamado');
        return 'Dados da playlist YouTube...';
    }
}
