<?php

defined('_JEXEC') or die;

use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\CMS\Factory;

return new class implements ServiceProviderInterface {
    public function register(Container $container)
    {
        $logger = Factory::getApplication()->getLogger();
        $logger->info('[mod_youtube_playlist] A registar serviço...');

        try {
            $container->set(
                \ModYoutubePlaylist\Module::class,
                function () use ($logger) {
                    $logger->info('[mod_youtube_playlist] A instanciar ModYoutubePlaylist\Module');
                    return new \ModYoutubePlaylist\Module();
                }
            );
        } catch (\Throwable $e) {
            $logger->error('[mod_youtube_playlist] ERRO: ' . $e->getMessage());
            throw $e;
        }
    }
};
