<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Layout\FileLayout;
use ModYoutubePlaylist\Module;

$app = Factory::getApplication();
$logger = $app->getLogger();

$logger->info('[mod_youtube_playlist] A carregar módulo');

try {
    /** @var Module $module */
    $moduleInstance = $app->getContainer()->get(Module::class);
    $data = $moduleInstance->getMessage();
} catch (Throwable $e) {
    $logger->error('[mod_youtube_playlist] ERRO ao obter módulo: ' . $e->getMessage());
    $data = 'Erro ao carregar dados.';
}

$layout = new FileLayout('default', __DIR__ . '/tmpl');
echo $layout->render(['data' => $data]);
