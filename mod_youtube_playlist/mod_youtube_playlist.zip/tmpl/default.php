<?php

use Joomla\CMS\Factory;

defined('_JEXEC') or die;


