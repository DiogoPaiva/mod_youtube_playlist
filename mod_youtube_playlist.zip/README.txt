# YouTube Playlist Module & Plugin
Module to load Youtube Playlist ID, using youtube API_KEY to validate the requests. For Joomla 5

To use:
1. Upload and install this package.
2. Go to Extensions > Plugins and publish "Ajax - YouTube Playlist".
3. Go to Extensions > Modules and add a new "YouTube Playlist" module.
4. Insert {loadposition custom} into an article to display the playlist.

API Key is stored in /configuration/youtube.php — keep it secure!
